const {onDocumentCreated} = require('firebase-functions/v2/firestore');
const {onCall, HttpsError} = require('firebase-functions/v2/https');
const {setGlobalOptions} = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({region: 'us-central1', maxInstances: 10});
const db = admin.firestore();

const SUPER_ADMIN_EMAIL = 'syd196829@gmail.com';
const WINDOW_MS = 60 * 1000;
const MAX_EVENTS_PER_WINDOW = 40;

function isSuperAdmin(context) {
  return !!context.auth && (context.auth.token.email || '').toLowerCase() === SUPER_ADMIN_EMAIL;
}

async function writeAlert(data) {
  await db.collection('securityAlerts').add({
    ...data,
    severity: data.severity || 'medium',
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    status: 'open'
  });
}

// AI Security Guard foundation:
// Detects suspicious event bursts and creates private owner-only alerts.
exports.securityGuardOnEvent = onDocumentCreated('securityEvents/{eventId}', async (event) => {
  const snap = event.data;
  if (!snap) return;
  const e = snap.data();
  const uid = e.uid;
  if (!uid) return;

  const since = admin.firestore.Timestamp.fromMillis(Date.now() - WINDOW_MS);
  const recent = await db.collection('securityEvents')
    .where('uid', '==', uid)
    .where('createdAt', '>=', since)
    .limit(MAX_EVENTS_PER_WINDOW + 1)
    .get();

  if (recent.size > MAX_EVENTS_PER_WINDOW) {
    await writeAlert({
      type: 'activity_burst',
      severity: 'high',
      uid,
      message: `Suspicious activity burst detected: ${recent.size} security events within one minute.`
    });
  }

  const suspicious = ['permission-denied', 'unauthorized-write', 'unauthorized-delete', 'rate-limit', 'upload-abuse', 'xss-attempt'];
  if (suspicious.includes(e.type)) {
    await writeAlert({
      type: e.type,
      severity: e.type === 'xss-attempt' || e.type === 'unauthorized-delete' ? 'high' : 'medium',
      uid,
      message: `Security event detected: ${e.type}`,
      path: e.path || null
    });
  }
});

// Server-authorized audit entry for future sensitive operations.
exports.recordSecurityEvent = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Authentication required.');
  const data = request.data || {};
  const type = String(data.type || '').slice(0, 80);
  const path = String(data.path || '').slice(0, 300);
  const allowed = new Set([
    'permission-denied','unauthorized-write','unauthorized-delete','rate-limit',
    'upload-abuse','xss-attempt','suspicious-login','account-recovery-abuse'
  ]);
  if (!allowed.has(type)) throw new HttpsError('invalid-argument', 'Unsupported security event.');

  await db.collection('securityEvents').add({
    uid: request.auth.uid,
    type,
    path,
    createdAt: admin.firestore.FieldValue.serverTimestamp()
  });
  return {ok: true};
});

// Owner-only health snapshot for a private security dashboard.
exports.getSecuritySummary = onCall(async (request) => {
  if (!isSuperAdmin(request)) throw new HttpsError('permission-denied', 'Owner access required.');
  const since = admin.firestore.Timestamp.fromMillis(Date.now() - 24 * 60 * 60 * 1000);
  const [alerts, events] = await Promise.all([
    db.collection('securityAlerts').where('createdAt', '>=', since).limit(100).get(),
    db.collection('securityEvents').where('createdAt', '>=', since).limit(500).get()
  ]);
  return {
    alerts24h: alerts.size,
    events24h: events.size,
    generatedAt: new Date().toISOString()
  };
});
