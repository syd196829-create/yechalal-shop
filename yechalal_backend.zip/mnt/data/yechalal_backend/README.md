# Yechalal Shop backend security package

This package keeps `index.html` unchanged in name and provides the server-side layer that cannot safely live in browser JavaScript.

Files:
- `firebase.json` — Firebase configuration.
- `firestore.rules` — default-deny Firestore rules with user/admin ownership checks.
- `firestore.indexes.json` — indexes for common existing queries.
- `functions/` — Cloud Functions including the owner-only AI Security Guard foundation.

Important:
1. Review existing collections and fields against the rules before deploying to production; the app contains more collections than any single static rule set can safely infer.
2. Deploy rules/indexes/functions from a Firebase-enabled environment.
3. The super-admin email currently used by the app is `syd196829@gmail.com`; change it in both the app and backend if the owner account changes.
4. Payment, wallet payout, and real-money processing are intentionally not implemented here.
5. The AI Security Guard is a security-event detection foundation, not a claim of autonomous intrusion prevention.
