Madam Kimem update - how to install (GitHub -> Vercel)
1) In your GitHub repo replace  api/chat.js  with the file from this zip.
2) Add the NEW file  api/lib/app-guide.js  (the api/lib folder already exists).
3) Commit. Vercel deploys automatically. No new environment variables are required.
   (Optional) OWNER_EMAIL env var - defaults to syd196829@gmail.com.
No new Vercel function is created (app-guide.js is only a helper inside api/lib).
